
        <!DOCTYPE html>
<html lang="en">
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="shortcut icon" href="/img/favicon.ico" type="image/x-icon" />

<title> Garena Mobile Arena </title>
<meta name="title" content= "Garena Mobile Arena - Main Moba di Mana Saja" />
<meta name="description" content="Mobile Arena segera hadir pada bulan Juni 2017 ini. Daftar Closed Beta Mobile Arena sekarang untuk mendapatkan hadiah spesial. The best you can get on mobile!" />
<meta name="keywords" content="moba,garena,game,mobile,mobile arena,5v5,3v3,1v1,garena indonesia,android,ios,apk,action,lol,dota,pvp,mobile legends,dota2,best moba,best game,tencent">
<link rel="image_src" href="https://moba.garena.co.id/img/og_img.jpg" />

<meta property="og:type" content="website" />
<meta property="fb:app_id" content="361640907293623" />
<meta property="og:locale" content="id" />
<meta property="og:title" content="Garena Mobile Arena" />
<meta property="og:description" content= "Mobile Arena segera hadir pada bulan Juni 2017 ini. Daftar Closed Beta Mobile Arena sekarang untuk mendapatkan hadiah spesial. The best you can get on mobile!" />
<meta property="og:image" content="https://moba.garena.co.id/img/og_img.jpg" />
<meta property="og:url" content="http://moba.co.id" />

    <!-- Bootstrap Core CSS -->
    <link href="https://moba.garena.co.id/redeem/assets/user/css/bootstrap.css" rel="stylesheet">
	    <link href="http://redeem.pb.garena.co.id/static/pbid2015/css/main.css" rel="stylesheet">


    <!-- Form Validation CSS -->
    <link href="https://moba.garena.co.id/redeem/assets/user/css/formValidation.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="https://moba.garena.co.id/redeem/assets/user/css/landing-page.css" rel="stylesheet">
    <link href="https://moba.garena.co.id/redeem/assets/user/css/kg-style.css" rel="stylesheet">
    <link href="https://moba.garena.co.id/redeem/assets/user/css/kg-style-register.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="https://moba.garena.co.id/redeem/assets/user/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">

    <!-- jQuery -->
    <script src="https://moba.garena.co.id/redeem/assets/user/js/jquery.js"></script>

    <!-- jQuery UI -->
    <script src="https://moba.garena.co.id/redeem/assets/user/js/jquery-ui.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="https://moba.garena.co.id/redeem/assets/user/js/bootstrap.min.js"></script>

    <!-- Form Validation -->
    <script src="https://moba.garena.co.id/redeem/assets/user/js/formValidation.min.js"></script>
    <script src="https://moba.garena.co.id/redeem/assets/user/js/framework/bootstrap.min.js"></script>

    <!-- Featherlight -->
    <link href="https://moba.garena.co.id/redeem/assets/user/css/featherlight.min.css" rel="stylesheet">
    <script src="https://moba.garena.co.id/redeem/assets/user/js/featherlight.min.js"></script>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>
    <!-- Navigation -->
    <nav class="navbar navbar-default navbar-fixed-top topnav" role="navigation">
        <div class="container topnav">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li class="daftar"style="display:none">
                        <a href="https://moba.garena.co.id/redeem/user/register">DAFTAR</a>
                    </li>
                    <li class="home" style="display:none">
                        <a href="https://moba.garena.co.id/redeem/">HOME</a>
                    </li>
                    <li class="blank">
                        <a href=""></a>
                    </li>
                    <li class="blank">
                        <a href=""></a>
                    </li>
                    <li class="appstore" style="display:none"></li>
                    <li class="googleplay" style="display:none"></li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>




    <!-- Header -->
    <a name="home"></a>
    <div class="register-header">
        <div class="container register">

            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="intro-message no-bot no-top">
                        <div class="logo"></div>
                        <div class="header" style="display:none"></div>
                        <div class="form">
                        <div class="timeline_text" style="display:none">
                            <div class="text">
                                <div class="name">Login</div>
                                <div class="step">STEP 1</div>
                            </div>
                            <div class="text" style="display:none">
                                <div class="name">Like</div>
                                <div class="step">STEP 2</div>
                            </div>
                            <div class="text" style="display:none">
                                <div class="name">&nbsp Share</div>
                                <div class="step">&nbsp STEP 3</div>
                            </div>
                            <div class="text">
                                <div class="name">&nbsp &nbsp Isi Data</div>
                                <div class="step">&nbsp &nbsp STEP 2</div>
                            </div>
                            <div class="text">
                                <div class="name">&nbsp &nbsp Selesai</div>
                                <div class="step">&nbsp &nbsp &nbsp STEP 3</div>
                            </div>
                        </div>
                                <h1><b>Cek Kode Redeem Registrasi Pre-CBT</b></h1>
                            <div class="timeline" style="display:none">
                                <ol>
                                  <li  style="visibility: hidden;"  class="active">
                                  </li>
                                  <li class="">
                                  </li>
                                  <li class="">
                                  </li>
                                  <li class="">
                                  </li>
                                  <li  style="visibility: hidden;"  class="">
                                    <!-- <span class="details">
                                      Description of point 3
                                    </span> -->
                                  </li>
                                </ol>
                            </div>
                            <div class="content">
    <div class="header"><hr class="left">
    <div class="middle">Tukar Kode</div>
    <hr class="right"></div>
    <div class="details">Kamu login sebagai, Challengers.</div>
	<div class="details">Bukan kamu? >> <a href="logout.php"><u>Logout</u></a></div>
    <br>
    
	<div id="divRedeem" class="redeembox">
			<h5>MASUKKAN KODE KAMU:</h5>
			<form id="redeemCodeForm" name="redeemCodeForm" action="" method="post">
				<input class="form-control" name="redeemcode" maxlength="19" type="text" />
				
				</br>
				
				<button name="submit" type="submit" class="btn-redeemnow"></button>

				<?php if(isset($_POST['submit'])){
					$code = $_POST['redeemcode'];
					$cek1 = $code;
					if($cek1 == "AOV1 PGZK SVNG 3BTK") {
					$pesan = "Selamat! Kamu mendapatkan Hero Langka Airi.";}
					elseif($cek1 == "AOV2 FWJM 17HR R6IX") {
						$pesan = "Selamat! Kamu mendapatkan Hero Joker.";
					}else {
						$pesan = "Kode Tidak Sah !";
					}
					echo $pesan;
				}?>
				
				<span id="redeemMessage" class="error-msg"></span>
			</form>
		</div>
		
	
	
</div>

<script>
$( ".facebook" ).click(function() {
  // alert('login');
  !function(f,b,e,v,n,t,s)
	{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
	n.callMethod.apply(n,arguments):n.queue.push(arguments)};
	if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
	n.queue=[];t=b.createElement(e);t.async=!0;
	t.src=v;s=b.getElementsByTagName(e)[0];
	s.parentNode.insertBefore(t,s)}(window,document,'script',
	'https://connect.facebook.net/en_US/fbevents.js');
	fbq('init', '601367413406077'); 
  fbq('track', 'Facebook_login');
});
</script>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-41152417-29', 'auto');
  ga('send', 'pageview');

</script>
                        </div>

                    </div>
                </div>
            </div>

        </div>
        <!-- /.container -->

    </div>
    <!-- /.intro-header -->

    <!-- Page Content -->


    <!-- Footer -->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                <div class="garena_footer"></div>
                    <p class="copyright text-muted small">Copyright &copy; Garena Online. Trademarks belong to their respective owners. All Rights Reserved</p>
                </div>
            </div>
        </div>
    </footer>

    <!-- Facebook Pixel Code -->
    <script>
    !function(f,b,e,v,n,t,s)
    {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
    n.callMethod.apply(n,arguments):n.queue.push(arguments)};
    if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
    n.queue=[];t=b.createElement(e);t.async=!0;
    t.src=v;s=b.getElementsByTagName(e)[0];
    s.parentNode.insertBefore(t,s)}(window,document,'script',
    'https://connect.facebook.net/en_US/fbevents.js');
    fbq('init', '601367413406077'); 
    fbq('track', 'PageView');
    </script>
    <noscript>
     <img height="1" width="1" 
    src="https://www.facebook.com/tr?id=601367413406077&ev=PageView
    &noscript=1"/>
    </noscript>
    <!-- End Facebook Pixel Code -->
    
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-41152417-29', 'auto');
  ga('send', 'pageview');

</script>


</body>

</html>
