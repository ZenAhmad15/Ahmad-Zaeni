function _onCliokReset() {
	_emptyTextBoxId('ccode');
}
